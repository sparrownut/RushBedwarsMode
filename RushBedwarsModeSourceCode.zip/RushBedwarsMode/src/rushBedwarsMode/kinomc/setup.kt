package rushBedwarsMode.kinomc

import rushBedwarsMode.kinomc.BlockExpendManager.BlockExpendManager
import rushBedwarsMode.kinomc.utils.utils
import org.bukkit.Bukkit
import org.bukkit.plugin.java.JavaPlugin

class setup : JavaPlugin() {
    companion object{
        lateinit var instance: setup
        var ExpendBlock = 5
    }
    override fun onEnable() {
        instance = this
        saveDefaultConfig()//第一次设置默认config
        Bukkit.getPluginManager().registerEvents(EventManager(),this)
        Bukkit.getPluginManager().registerEvents(BlockExpendManager(),this)
        ExpendBlock = config.getInt("Expend_BLock")
        utils().BukkitSendMessageRe("&a急速起床插件已经加载")
    }

    override fun onDisable() {
        utils().BukkitSendMessageRe("&c急速起床插件已经卸载")
    }

}