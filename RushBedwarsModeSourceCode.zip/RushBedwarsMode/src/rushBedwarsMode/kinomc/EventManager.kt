package rushBedwarsMode.kinomc

import rushBedwarsMode.kinomc.BlockExpendManager.BlockExpendManager
import org.bukkit.event.EventHandler
import org.bukkit.event.Listener
import org.bukkit.event.player.PlayerInteractEvent

class EventManager:Listener {
    @EventHandler
    fun onClick(event:PlayerInteractEvent){
        BlockExpendManager().clickEvent(event)
    }
}