package rushBedwarsMode.kinomc.BedwarsProtect

import java.util.ArrayList


import io.github.bedwarsrel.game.Game
import io.github.bedwarsrel.game.Team
import org.bukkit.Location
import org.bukkit.Material
import org.bukkit.World
import java.util.function.Consumer
import io.github.bedwarsrel.game.TeamColor





class ProtectBuilding {
    fun placeBedProtect(game: Game, team: Team, loc1: Location, loc2: Location): Boolean {
        val world: World = loc1.world
        val bedProtectFirst = ArrayList<Location>()
        listOf(loc1, loc2).forEach(Consumer { loc: Location ->
            bedProtectFirst.add(Location(world, loc.x, loc.y, loc.z - 1.0))
            bedProtectFirst.add(Location(world, loc.x, loc.y, loc.z + 1.0))//z轴两个防护
            bedProtectFirst.add(Location(world, loc.x, loc.y + 1.0, loc.z))//纵轴一个
            bedProtectFirst.add(Location(world, loc.x - 1.0, loc.y, loc.z))
            bedProtectFirst.add(Location(world, loc.x + 1.0, loc.y, loc.z))//x轴两个防护
        })//添加第1层的每个方块位置
        val bedProtectSecond = ArrayList<Location>()
        bedProtectFirst.forEach(Consumer { loc: Location ->
            bedProtectSecond.add(Location(world, loc.x, loc.y, loc.z - 1.0))
            bedProtectSecond.add(Location(world, loc.x, loc.y, loc.z + 1.0))
            bedProtectSecond.add(Location(world, loc.x, loc.y + 1.0, loc.z))
            bedProtectSecond.add(Location(world, loc.x - 1.0, loc.y, loc.z))
            bedProtectSecond.add(Location(world, loc.x + 1.0, loc.y, loc.z))

        })//添加第2层的每个方块位置
        val bedProtectThird = ArrayList<Location>()
        bedProtectSecond.forEach(Consumer { loc: Location ->
            bedProtectThird.add(Location(world, loc.x - 1.0, loc.y, loc.z))
            bedProtectThird.add(Location(world, loc.x + 1.0, loc.y, loc.z))
            bedProtectThird.add(Location(world, loc.x, loc.y, loc.z - 1.0))
            bedProtectThird.add(Location(world, loc.x, loc.y, loc.z + 1.0))
            bedProtectThird.add(Location(world, loc.x, loc.y + 1.0, loc.z))

        })//添加第3层的每个方块位置
        bedProtectFirst.forEach(Consumer { block: Location ->//第一层木头
            if(block.block.type == Material.AIR) {
                block.block.type = Material.WOOD
                game.region.addPlacedBlock(block.block, null)//设置可破坏
            }
        })
        bedProtectSecond.forEach(Consumer { block: Location ->//第二层羊毛
            if(block.block.type == Material.AIR) {
                block.block.type = Material.WOOL
                block.block.setData(ReturnTeamColorID(team.color))//设置颜色成队伍
                game.region.addPlacedBlock(block.block, null)
            }
        })
        bedProtectThird.forEach(Consumer { block: Location ->//第三层玻璃
            if(block.block.type == Material.AIR) {
                block.block.type = Material.STAINED_GLASS
                block.block.setData(ReturnTeamColorID(team.color))
                game.region.addPlacedBlock(block.block, null)
            }
        })
        return true
    }
    private fun ReturnTeamColorID(teamcolor: TeamColor): Byte {
        return when(teamcolor){
            TeamColor.GREEN -> 5
            TeamColor.YELLOW -> 4
            TeamColor.BLUE -> 11
            TeamColor.RED -> 14
            else -> 100
        }

    }
}